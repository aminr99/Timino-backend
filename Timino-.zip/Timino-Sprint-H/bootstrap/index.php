<?php

require_once 'dotenv.php';

require_once 'config.php';

require_once 'bootstrap/functions.php';

require 'bootstrap/database.php';

require_once 'bootstrap/router.php';


