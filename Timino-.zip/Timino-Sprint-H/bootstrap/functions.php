<?php

function dd($input)
{
    die(var_dump($input));
}
